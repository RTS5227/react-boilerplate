package services

import (
	"errors"
	"github.com/dgrijalva/jwt-go"
	"gobook/models"
	"net/http"
	"strings"
	"time"
)

const (
	SignKey = "G-Lnz5ag&4dPKX~_dwkBDa>Cfv6=8Qe$@#eFb4NxUF=#v~CvuA@FnY=p4CtX;BPtSW-6hP<y7G$JV4yVv^m6-4z"
)

func GetToken(claims *models.Claims) (string, error) {
	claims.StandardClaims = jwt.StandardClaims{
		ExpiresAt: time.Now().Add(time.Hour * 72).Unix(),
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	// Sign and get the complete encoded token as string
	return token.SignedString([]byte(SignKey))
}

func ParseToken(unparsedToken string) (interface{}, error) {
	token, err := jwt.Parse(unparsedToken, func(token *jwt.Token) (interface{}, error) {
		return []byte(SignKey), nil
	})
	return token.Claims, err
}

func ParseFromRequest(req *http.Request) (interface{}, error) {

	// Look for an Authorization header
	if ah := req.Header.Get("Authorization"); ah != "" {
		// Should be a bearer token
		if len(ah) > 6 && strings.ToUpper(ah[0:6]) == "BEARER" {
			return ParseToken(ah[7:])
		}
	}

	// Look for "access_token" parameter
	req.ParseMultipartForm(10e6)
	if tokStr := req.Form.Get("access_token"); tokStr != "" {
		return ParseToken(tokStr)
	}

	return nil, errors.New("No token present in request.")

}
