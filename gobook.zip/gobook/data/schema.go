package data

import (
	"github.com/graphql-go/graphql"
	"github.com/graphql-go/relay"
	"golang.org/x/net/context"

	"strconv"
)

var bookType *graphql.Object
var chapterType *graphql.Object
var nodeDefinitions *relay.NodeDefinitions
var chapterConnection *relay.GraphQLConnectionDefinitions
var bookConnection *relay.GraphQLConnectionDefinitions

var Schema graphql.Schema

func init() {
	/**
	* We get the node interface and field from the Relay library
	*
	* The first method defines the way we resolve an ID to its object
	* The second method defines the way we resolve an object to its GRAPHQL type.
	**/
	nodeDefinitions = relay.NewNodeDefinitions(relay.NodeDefinitionsConfig{
		IDFetcher: func(id string, info graphql.ResolveInfo, ct context.Context) (interface{}, error) {
			resolveID := relay.FromGlobalID(id)
			if resolveID.Type == "Book" {
				return GetBook(resolveID.ID), nil
			}
			if resolveID.Type == "Chapter" {
				return GetChapter(resolveID.ID), nil
			}
			return nil, nil
		},
		TypeResolve: func(p graphql.ResolveTypeParams) *graphql.Object {
			switch p.Value.(type) {
			case *Book:
				return bookType
			case *Chapter:
				return chapterType
			}
			return nil
		},
	})

	/**
	 * Define your type here
	 **/

	chapterType = graphql.NewObject(graphql.ObjectConfig{
		Name:        "Chapter",
		Description: "The chapter of the book",
		Fields: graphql.Fields{
			"id": relay.GlobalIDField("Chapter", nil),
			"text": &graphql.Field{
				Type:        graphql.String,
				Description: "The text content of the chapter",
				Resolve: func(p graphql.ResolveParams) (interface{}, error) {
					return p.Source.(*Chapter).Text, nil
				},
			},
		},
		Interfaces: []*graphql.Interface{
			nodeDefinitions.NodeInterface,
		},
	})

	chapterConnection = relay.ConnectionDefinitions(relay.ConnectionConfig{
		Name:     "ChapterConnection",
		NodeType: chapterType,
	})

	bookType = graphql.NewObject(graphql.ObjectConfig{
		Name:        "Book",
		Description: "A book object",
		Fields: graphql.Fields{
			"id": relay.GlobalIDField("Book", nil),
			"title": &graphql.Field{
				Type:        graphql.String,
				Description: "The title of the book",
				Resolve: func(p graphql.ResolveParams) (interface{}, error) {
					// p.Context.Value("current_user")
					return p.Source.(*Book).Title, nil
				},
			},
			"chapters": &graphql.Field{
				Type:        chapterConnection.ConnectionType,
				Description: "The chapters of the book",
				Args:        relay.ConnectionArgs,
				Resolve: func(p graphql.ResolveParams) (interface{}, error) {
					args := relay.NewConnectionArguments(p.Args)
					dataSlice := ChaptersToInterfaceSlice(GetChapters()...)
					return relay.ConnectionFromArray(dataSlice, args), nil
				},
			},
		},
		Interfaces: []*graphql.Interface{
			nodeDefinitions.NodeInterface,
		},
	})

	bookConnection = relay.ConnectionDefinitions(relay.ConnectionConfig{
		Name:     "BookConnection",
		NodeType: bookType,
	})

	/**
	 * This is the type that will be the root of our query,
	 * and the entry point into our schema.
	 **/
	viewerType := graphql.NewObject(graphql.ObjectConfig{
		Name: "Viewer",
		Fields: graphql.Fields{
			"node": nodeDefinitions.NodeField,

			//And you own root fields here
			"book": &graphql.Field{
				Type: bookType,
				Resolve: func(p graphql.ResolveParams) (interface{}, error) {
					return GetBook("1"), nil
				},
			},

			"chapter": &graphql.Field{
				Type: chapterType,
				Args: graphql.FieldConfigArgument{
					"id": &graphql.ArgumentConfig{
						Type: graphql.Int,
					},
				},
				Resolve: func(p graphql.ResolveParams) (interface{}, error) {
					id := strconv.Itoa(p.Args["id"].(int))
					return GetChapter(id), nil
				},
			},

			"books": &graphql.Field{
				Type: bookConnection.ConnectionType,
				Resolve: func(p graphql.ResolveParams) (interface{}, error) {
					args := relay.NewConnectionArguments(p.Args)
					dataSlice := BooksToInterfaceSlice(GetBooks()...)
					return relay.ConnectionFromArray(dataSlice, args), nil
				},
			},
		},
	})

	queryType := graphql.NewObject(graphql.ObjectConfig{
		Name: "Query",
		Fields: graphql.Fields{
			"node": nodeDefinitions.NodeField,

			"viewer": &graphql.Field{
				Type: viewerType,
				Resolve: func(p graphql.ResolveParams) (interface{}, error) {
					return GetBooks(), nil
				},
			},
		},
	})

	/**
	 * This is the type that will be the root of our mutation,
	 * and the entry point into performing writes in our schema.
	 **/
	/*mutationType := graphql.NewObject(graphql.ObjectConfig{
	    Name: "Mutation",
	    Fields: graphql.Fields{},
	})*/

	/**
	 * Finnally, we construct our schema (whose starting query type is the query
	 * type we defined above) and export it
	 **/
	var err error
	Schema, err = graphql.NewSchema(graphql.SchemaConfig{
		Query: queryType,
	})
	if err != nil {
		panic(err)
	}
}
