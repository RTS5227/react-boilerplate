package data

type Book struct {
	ID    string `json:"id"`
	Title string `json:"text"`
}
type Chapter struct {
	ID     string `json:"id"`
	Text   string `json:"text"`
	BookID string `json:"text"`
}

var books []*Book = []*Book{
	&Book{"1", "Harry Potter"},
	&Book{"2", "Game of throne"},
}
var chapters []*Chapter = []*Chapter{
	&Chapter{"1", "Hello world", "1"},
	&Chapter{"2", "hi", "2"},
}

func GetBook(id string) *Book {
	for _, b := range books {
		if b.ID == id {
			return b
		}
	}
	return nil
}

func GetChapter(id string) *Chapter {
	for _, c := range chapters {
		if c.ID == id {
			return c
		}
	}
	return nil
}

func GetBooks() []*Book {
	return books
}

func GetChapters() []*Chapter {
	return chapters
}

func ChaptersToInterfaceSlice(chapters ...*Chapter) []interface{} {
	interfaceSlice := make([]interface{}, len(chapters))
	for i, c := range chapters {
		interfaceSlice[i] = c
	}
	return interfaceSlice
}

func BooksToInterfaceSlice(books ...*Book) []interface{} {
	interfaceSlice := make([]interface{}, len(chapters))
	for i, c := range books {
		interfaceSlice[i] = c
	}
	return interfaceSlice
}
