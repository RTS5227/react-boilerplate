package main

import (
	"encoding/json"
	"fmt"
	"github.com/graphql-go/graphql"
	"gobook/data"
	"gobook/models"
	"gobook/services"
	"golang.org/x/net/context"
	"log"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
)

const (
	GB_GRAPHQL_PORT  = "GB_GRAPHQL_PORT"
	GB_FRONTEND_HOST = "GB_FRONTEND_HOST"
	GB_FRONTEND_PORT = "GB_FRONTEND_PORT"
	GB_GRAPHIQL_HOST = "GB_GRAPHIQL_HOST"
	GB_GRAPHIQL_PORT = "GB_GRAPHIQL_PORT"
)

type Query struct {
	Query string `json:"query"`
}

func graphqlHandler(w http.ResponseWriter, r *http.Request) {
	claims, _ := services.ParseFromRequest(r)
	decoder := json.NewDecoder(r.Body)
	var query Query
	err := decoder.Decode(&query)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	defer r.Body.Close()
	result := graphql.Do(graphql.Params{
		Schema:        data.Schema,
		RequestString: query.Query,
		Context:       context.WithValue(context.Background(), "current_user", claims),
	})
	if len(result.Errors) > 0 {
		log.Printf("wrong result, unexpected errors: %v", result.Errors)
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	JsonResponse(result, w)
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	/*var user models.UserCredentials
	// decode request to UserCredentials struct
	err := json.NewDecoder(r.Body).Decode(&user)
	if err != nil {
		w.WriteHeader(http.StatusForbidden)
		return
	}*/
	tokenString, err := services.GetToken(&models.Claims{
		UserId:   "1",
		Username: "god",
		Email:    "god@admin.com",
	})
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprintln(w, "Error while signing the token")
	}
	JsonResponse(models.Token{tokenString}, w)
}

func main() {
	http.HandleFunc("/graphql", graphqlHandler)
	http.HandleFunc("/login", loginHandler)
	// Proxy to Graphiql Server
	target, err := url.Parse("http://" + os.Getenv(GB_GRAPHIQL_HOST) + ":" + os.Getenv(GB_GRAPHIQL_PORT))
	if err != nil {
		log.Fatal(err)
	}
	http.Handle("/graphiql/", http.StripPrefix("/graphiql/", httputil.NewSingleHostReverseProxy(target)))
	// Proxy to Frontend Server
	target, err = url.Parse("http://" + os.Getenv(GB_FRONTEND_HOST) + ":" + os.Getenv(GB_FRONTEND_PORT))
	if err != nil {
		log.Fatal(err)
	}
	http.Handle("/", http.StripPrefix("/", httputil.NewSingleHostReverseProxy(target)))
	// Start
	port := ":" + os.Getenv(GB_GRAPHQL_PORT)
	log.Printf("GraphQL server starting up on http://localhost%v\n", port)
	err = http.ListenAndServe(port, nil)
	if err != nil {
		log.Fatalf("ListenAndServe failed, %v", err)
	}
}

//HELPER FUNCTIONS

func JsonResponse(response interface{}, w http.ResponseWriter) {

	json, err := json.Marshal(response)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
	w.Header().Set("Content-Type", "application/json")
	w.Write(json)
}
