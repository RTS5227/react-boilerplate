package services

import (
	"fmt"
	"gobook/models"
	"os"
	"testing"
)

func TestGetToken(t *testing.T) {
	fmt.Println("Key: ", os.Getenv("GB_PRIV_KEY"))
	tokenString, err := GetToken(&models.Claims{
		UserId:   "1",
		Username: "god",
		Email:    "god@admin.com",
	})
	if err != nil {
		t.Error(err)
		return
	}
	fmt.Println("Got Token ", tokenString)
}

func TestParseToken(t *testing.T) {
	tokenPayload, err := ParseToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiIxIiwibmFtZSI6ImdvZCIsImVtYWlsIjoiZ29kQGFkbWluLmNvbSIsInJvbGUiOiIiLCJleHAiOjE0OTMwNDk0MDN9.yZhDSZrZgYnR_FCmmjIc8WjFIzEgKpbqoNOP2w9L0Mc")
	if err != nil {
		t.Error(err)
		return
	}
	fmt.Println(tokenPayload)
}
